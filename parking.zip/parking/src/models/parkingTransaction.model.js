import mongoose, {Schema} from "mongoose";

const parkingTransactionSchema = new mongoose.Schema({
    parkingLevel: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ParkingLevel',
        required: true,
    },
    type: {
        type: String,
        required: true,
        enum: ['2-wheeler', '4-wheeler'],
    },
    parkingSpaceId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ParkingSpace',
        required: true,
    },
    bookingDateTime: {
        type: Date,
        required: true,
    },
    releaseDateTime: {
        type: Date,
        required: false,
    },
    vehicleNo: {
        type: String,
        required: true,
        trim: true,
    },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
    },
});

parkingTransactionSchema.pre('save', function (next) {
    if (this.releaseDateTime && this.releaseDateTime <= this.bookingDateTime) {
        return next(new Error('Release date must be after booking date.'));
    }
    next();
});

export const ParkingTransaction = mongoose.model('ParkingTransaction', parkingTransactionSchema);
