
import { ParkingTransaction } from '../models/parkingTransaction.model.js';
import { ParkingSpace } from '../models/parkingSpace.model.js';

export const getAllParkingTransactions = async (req, res) => {
    try {
        const { userId, vehicleNo, startDate, endDate } = req.query;
        let filter = {};

        if (userId) filter.userId = userId;
        if (vehicleNo) filter.vehicleNo = vehicleNo;
        if (startDate && endDate) {
            filter.bookingDateTime = { $gte: new Date(startDate), $lte: new Date(endDate) };
        }

        const parkingTransactions = await ParkingTransaction.find(filter);
        res.json(parkingTransactions);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const getParkingTransactionById = async (req, res) => {
    try {
        const parkingTransaction = await ParkingTransaction.findById(req.params.id);
        if (!parkingTransaction) {
            return res.status(404).json({ message: "Parking transaction not found" });
        }
        res.json(parkingTransaction);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const createParkingTransaction = async (req, res) => {
    try {
        const { parkingLevel, type, parkingSpaceId, bookingDateTime, vehicleNo, userId } = req.body;

        // Check if the parking space is available
        const parkingSpace = await ParkingSpace.findById(parkingSpaceId);
        if (!parkingSpace) {
            return res.status(404).json({ message: "Parking space not found" });
        }
        if (!parkingSpace.isAvailable) {
            return res.status(400).json({ message: "Parking space is not available" });
        }

        // Create the parking transaction
        const newParkingTransaction = new ParkingTransaction({
            parkingLevel,
            type,
            parkingSpaceId,
            bookingDateTime,
            vehicleNo,
            userId
        });

        // Save the transaction
        await newParkingTransaction.save();

        // Mark the parking space as occupied
        parkingSpace.isAvailable = false;
        await parkingSpace.save();

        res.status(201).json(newParkingTransaction);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

export const releaseParkingTransaction = async (req, res) => {
    try {
        const { releaseDateTime } = req.body;

        // Find the parking transaction
        const parkingTransaction = await ParkingTransaction.findById(req.params.id);
        if (!parkingTransaction) {
            return res.status(404).json({ message: "Parking transaction not found" });
        }

        // Update the transaction with release date
        parkingTransaction.releaseDateTime = releaseDateTime;
        await parkingTransaction.save();

        // Mark the parking space as available
        const parkingSpace = await ParkingSpace.findById(parkingTransaction.parkingSpaceId);
        if (parkingSpace) {
            parkingSpace.isAvailable = true;
            await parkingSpace.save();
        }

        res.json(parkingTransaction);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
