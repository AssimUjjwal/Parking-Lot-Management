import {Router} from 'express';
import { getAllParkingTransactions, getParkingTransactionById, releaseParkingTransaction, createParkingTransaction } from '../controllers/parkingTransaction.controller.js';

const router = Router();

router.route("/").get(getAllParkingTransactions);
router.route("/").post(createParkingTransaction);
router.route("/:id").get(getParkingTransactionById);
router.route("/:id").put(releaseParkingTransaction);

export default router;