import { Router } from 'express';
import { getAllParkingSpaces, getParkingSpaceById, updateParkingSpaceById } from '../controllers/parkingSpace.controller.js';

const router = Router();

router.route("/").get(getAllParkingSpaces);
router.route("/:id").get(getParkingSpaceById);
router.route("/:id").put(updateParkingSpaceById);

export default router;